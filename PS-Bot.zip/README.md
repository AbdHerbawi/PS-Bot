# **Best Copy of Probot Bot By SHADOW#1289**

**Welcome Readme 🙃**

## 💨 Run the projects

Twitter: [![Run on Twitter](https://twitter.com/AbdHerbawi)](AbdHerbawi)

YouTube: [![Run on YouTube](https://www.youtube.com/channel/UClkMaEGza1HH1DO_-PNO_lA)](PS_SHADOW)

### ⚡ Installation

go to `Config` folder and edit configuration.json file

```js
{
    "token":"You Disocrd Bot Token",
    "prefix": "Tou Discord Bot Prefix",
    "website":"You Website our dashboard (in website folder you will find a soo simple website it have all bot commands)",
    "youtubekey":"You Youtube API V3",
    "roomid":"You Voice Channel Id Bot Will Stay in"
}
```

## ✨ Mad By

```SHADOW#1289```

## 🌀 Support

Server Support: https://discord.gg/BTc3FGTRSh

